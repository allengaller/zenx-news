<div class="ad">
	<div class="ads">
		<div class="ads_c"><!-- nuffnang -->
<script type="text/javascript">
nuffnang_bid = "079abc3f48839d070b069887236d2a70";
document.write( "<div id='nuffnang_sq'></div>" );
(function() {	
var nn = document.createElement('script'); nn.type = 'text/javascript';    
nn.src = 'http://synad2.nuffnang.com.cn/sq2.js';    
var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(nn, s.nextSibling);
})();
</script>
<!-- nuffnang-->
			<div class="clear"></div>
		</div>
		<div class="box-bottom">
		</div>
	</div>
</div>