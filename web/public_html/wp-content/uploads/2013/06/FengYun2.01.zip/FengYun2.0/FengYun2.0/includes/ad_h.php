<div class="ad_h">
		<div class="ad_h_c">
			<p align="center"><?php echo stripslashes(get_option('swt_adh_c')); ?></p>
			<div class="clear"></div>
		</div>
</div>
<div class="entry_box_b">
</div>