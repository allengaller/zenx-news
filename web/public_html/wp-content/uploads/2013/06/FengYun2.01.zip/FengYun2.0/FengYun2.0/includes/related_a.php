<div class="entry_b">
	<?php include('related.php'); ?>
	<?php include('related_img.php'); ?>
	<div class="clear"></div>
</div>
<div class="entry_sb">
</div>