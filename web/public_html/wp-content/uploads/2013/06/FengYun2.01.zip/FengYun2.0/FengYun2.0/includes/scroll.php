<ul class="scroll">
	<li class="sct">
		<a href="#">&nbsp;&nbsp;&nbsp;</a>
		<div><a class="scroll_t" title="返回顶部">返回顶部</a></div>
	</li>
	<?php if(is_single() || is_page()) { ?>
	<li class="scc">
		<a href="#">&nbsp;&nbsp;&nbsp;</a>
		<div><a class="scroll_c" title="查看留言">查看留言</a></div>
	</li>
	<?php } ?>
	<li class="scb">
		<a href="#">&nbsp;&nbsp;&nbsp;</a>
		<div><a class="scroll_b" title="转到底部">转到底部</a></div>
	</li>
</ul>