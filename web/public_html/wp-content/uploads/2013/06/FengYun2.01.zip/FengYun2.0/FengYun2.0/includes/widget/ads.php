<div class="ad">
	<div class="ads">
		<div class="ads_c"><p align="center"><?php echo stripslashes(get_option('swt_adsc')); ?></p>
			<div class="clear"></div>
		</div>
		<div class="box-bottom">
		</div>
	</div>
</div>