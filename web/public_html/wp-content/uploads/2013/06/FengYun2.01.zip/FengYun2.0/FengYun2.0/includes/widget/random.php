<div class="random_r">
	<h3>随便看看</h3>
	<div class="box_r">
		<ul><?php s_random_lists(); ?></ul>
		<div class="clear"></div>
	</div>
	<div class="box-bottom">
	</div>
</div>