<h3>热门标签</h3>
<div class="categories">
	<div class="tag_c"><?php wp_tag_cloud('smallest=12&largest=16&unit=px&number=35');?></div>
</div>
<div class="clear"></div>
<div class="box-bottom">
</div>