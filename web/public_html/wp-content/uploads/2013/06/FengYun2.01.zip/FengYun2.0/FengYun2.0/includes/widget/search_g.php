<h3>站内搜索</h3>
<div class="box_c">
	<div class="search_k">
		<form method="get" id="searchform" action="<?php bloginfo('url'); ?>/">
			<input type="text" name="s" id="s" class="swap_value" size="26"/>
			<input type="image" src="<?php bloginfo('template_directory'); ?>/images/go.gif" id="go" alt="Search" title="搜索" />
		</form>
	</div>
</div>
<div class="box-bottom">
	<i class="lb"></i>
	<i class="rb"></i>
</div>